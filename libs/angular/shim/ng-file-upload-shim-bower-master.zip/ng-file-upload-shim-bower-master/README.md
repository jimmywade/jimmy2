angular-file-upload-shim-bower
==============================

bower distribution of [angular-file-upload](https://github.com/danialfarid/angular-file-upload) shim file.
All issues and pull request must be sumbitted to [angular-file-upload](https://github.com/danialfarid/angular-file-upload)
